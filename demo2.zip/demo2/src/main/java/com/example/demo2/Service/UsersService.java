package com.example.demo2.Service;

import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Users;
import com.example.demo2.mapper.UserMapper;
import com.example.demo2.mapper.UsersMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersService {
    @Autowired
    private UsersMapper usersMapper;
    public void add(Users users) {
        usersMapper.add(users);
    }

    public int delete(int id) {
        return usersMapper.delete(id);
    }

    public int update(Users users) {
        return usersMapper.update(users);
    }

    public List<Menu> select(int pageNum, int pageSize) {
        return usersMapper.select(pageNum,pageSize);
    }
}
