package com.example.demo2.mapper;

import com.example.demo2.entity.Menu;

import java.util.List;

public interface MenuMapper {
    void add(Menu menu);

    int delete(int mId);

    int update(Menu menu);

    List<Menu> select(int pageNum, int pageSize);
}
