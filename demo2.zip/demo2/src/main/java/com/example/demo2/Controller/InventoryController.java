package com.example.demo2.Controller;

import com.example.demo2.Service.InventoryService;
import com.example.demo2.Service.MenuService;
import com.example.demo2.entity.Inventory;
import com.example.demo2.entity.Menu;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/Inventory")
public class InventoryController {
    @Autowired
    private InventoryService inventoryService;
    @RequestMapping("/add")
    public ResponseEntity<String> add(@RequestBody Inventory inventory) {
        log.info("接收到库存信息: {}", inventory);
        try {
            inventoryService.add(inventory);
            return ResponseEntity.ok("添加成功");
        } catch (Exception e) {
            log.error("添加库存失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("添加失败: " + e.getMessage());
        }
    }
    @RequestMapping("/delete")
    public int delete(@RequestParam int id) {
        int isDeleted = inventoryService.delete(id);
        log.info("删除成功：id={}", id);
        return isDeleted;
    }
    @PutMapping("/update")
    public int update(@RequestBody Inventory inventory) {
        int updatedScore = inventoryService.update(inventory);
        log.info("更新成功:"+"id:"+inventory.getId()+"名称："+inventory.getName()+"总计："+inventory.getTotal()+"剩余："+inventory.getRemaining());
        return updatedScore;
    }


    @RequestMapping("/select")
    public List<Menu> select(@RequestParam(defaultValue = "1") int pageNum,
                             @RequestParam(defaultValue = "10") int pageSize) {
        log.info("查询成功，页码={}，每页大小={}", pageNum, pageSize);
        return inventoryService.select(pageNum, pageSize);
    }
}