package com.example.demo2.Service;


import com.example.demo2.entity.Orders;
import com.example.demo2.mapper.OrdersMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrdersService {

    @Autowired
    private OrdersMapper ordersMapper;

    public void saveOrder(Orders orders) {
        ordersMapper.insertOrder(orders);
    }
}