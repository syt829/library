package com.example.demo2.entity;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class Orders {
    private String items; // 改为 String 类型
    private double totalPrice;

    // Getters and Setters
    public String getItems() {
        return items;
    }

    public void setItems(String items) {
        this.items = items;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    // 将 List<OrderItem> 转换为 JSON 字符串
    public void setOrderItems(List<OrderItem> orderItems) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            this.items = objectMapper.writeValueAsString(orderItems);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize order items", e);
        }
    }

    // 将 JSON 字符串转换为 List<OrderItem>
    public List<OrderItem> getOrderItems() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.readValue(this.items, objectMapper.getTypeFactory().constructCollectionType(List.class, OrderItem.class));
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to deserialize order items", e);
        }
    }
}