package com.example.demo2.Controller;

import com.example.demo2.Service.UserService;
import com.example.demo2.entity.User;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/login")
    public String login(@RequestParam String name,
                        @RequestParam String password,
                        HttpServletRequest request,
                        HttpServletResponse response) {

        User user = userService.login(name, password);

        if (user != null) {
            // 1. 创建Session并存储用户信息
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setMaxInactiveInterval(30 * 60); // 设置session过期时间(秒)

            // 2. 创建Cookie
            Cookie userCookie = new Cookie("username", name);
            userCookie.setMaxAge(24 * 60 * 60); // 设置cookie存活时间(秒)
            userCookie.setPath("/"); // 设置cookie路径
            response.addCookie(userCookie);

            return "登录成功";
        } else {
            return "用户名或密码不正确";
        }
    }

    @RequestMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        // 1. 使Session失效
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        // 2. 删除Cookie
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("username")) {
                    cookie.setValue("");
                    cookie.setPath("/");
                    cookie.setMaxAge(0); // 立即过期
                    response.addCookie(cookie);
                    break;
                }
            }
        }

        return "登出成功";
    }

    @RequestMapping("/checkLogin")
    public String checkLogin(HttpServletRequest request) {
        // 1. 检查Session
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            return "用户已登录: " + ((User) session.getAttribute("user")).getName();
        }

        // 2. 检查Cookie
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("username")) {
                    return "通过Cookie检测到用户: " + cookie.getValue();
                }
            }
        }

        return "用户未登录";
    }
}