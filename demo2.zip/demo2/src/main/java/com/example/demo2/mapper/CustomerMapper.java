package com.example.demo2.mapper;

import com.example.demo2.entity.Customer;
import com.example.demo2.entity.Menu;

import java.util.List;

public interface CustomerMapper {
    void add(Customer customer);

    int delete(int id);

    int update(Customer customer);

    List<Menu> select(int pageNum, int pageSize);
}
