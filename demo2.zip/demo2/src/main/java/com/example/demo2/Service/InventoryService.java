package com.example.demo2.Service;

import com.example.demo2.entity.Inventory;
import com.example.demo2.entity.Menu;
import com.example.demo2.mapper.InventoryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private InventoryMapper inventoryMapper;
    public void add(Inventory inventory) {
        inventoryMapper.add(inventory);
    }

    public int delete(int id) {
        return inventoryMapper.delete(id);
    }

    public int update(Inventory inventory) {
        return inventoryMapper.update(inventory);
    }

    public List<Menu> select(int pageNum, int pageSize) {
        return inventoryMapper.select(pageNum,pageSize);
    }
}
