package com.example.demo2.Service;


import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Suggest;
import com.example.demo2.mapper.SuggestMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SuggestService {
    @Autowired
    private SuggestMapper suggestMapper;

    public void add(Suggest suggest) {
        suggestMapper.add(suggest);
    }

    public int delete(int id) {
        return suggestMapper.delete(id);
    }

    public int update(Suggest suggest) {
        return suggestMapper.update(suggest);
    }

    public List<Menu> select(int pageNum, int pageSize) {
        return suggestMapper.select(pageNum,pageSize);
    }
}
