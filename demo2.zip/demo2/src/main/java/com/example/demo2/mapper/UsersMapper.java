package com.example.demo2.mapper;

import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Users;

import java.util.List;

public interface UsersMapper {
    void add(Users users);

    int delete(int id);

    int update(Users users);

    List<Menu> select(int pageNum, int pageSize);
}
