package com.example.demo2.mapper;

import com.example.demo2.entity.Inventory;
import com.example.demo2.entity.Menu;

import java.util.List;

public interface InventoryMapper {
    void add(Inventory inventory);

    int delete(int id);

    int update(Inventory inventory);

    List<Menu> select(int pageNum, int pageSize);
}
