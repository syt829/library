package com.example.demo2.Controller;

import com.example.demo2.Service.MenuService;
import com.example.demo2.Service.UsersService;
import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Users;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/users")
public class UsersController {
    @Autowired
    private UsersService usersService;
    @RequestMapping("/add")
    public ResponseEntity<String> add(@RequestBody Users users) {
        log.info("接收管理员信息: {}", users);
        try {
            usersService.add(users);
            return ResponseEntity.ok("添加成功");
        } catch (Exception e) {
            log.error("添加失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("添加失败: " + e.getMessage());
        }
    }
    @RequestMapping("/delete")
    public int delete(@RequestParam int id) {
        int isDeleted = usersService.delete(id);
        log.info("删除成功：id={}", id);
        return isDeleted;
    }
    @PutMapping("/update")
    public int update(@RequestBody Users users) {
        int updatedScore = usersService.update(users);
        log.info("更新成功:"+"id:"+users.getId()+"姓名："+users.getName()+"密码："+users.getPassword());
        return updatedScore;
    }


    @RequestMapping("/select")
    public List<Menu> select(@RequestParam(defaultValue = "1") int pageNum,
                             @RequestParam(defaultValue = "10") int pageSize) {
        log.info("查询成功，页码={}，每页大小={}", pageNum, pageSize);
        return usersService.select(pageNum, pageSize);
    }
}