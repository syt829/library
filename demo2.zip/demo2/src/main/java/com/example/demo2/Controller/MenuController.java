package com.example.demo2.Controller;

import com.example.demo2.Service.MenuService;
import com.example.demo2.entity.Menu;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/scores")
public class MenuController {
    @Autowired
    private MenuService menuService;
    @RequestMapping("/add")
    public ResponseEntity<String> add(@RequestBody Menu menu) {
        log.info("接收到菜单信息: {}", menu);
        try {
            menuService.add(menu);
            return ResponseEntity.ok("添加成功");
        } catch (Exception e) {
            log.error("添加菜单失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("添加失败: " + e.getMessage());
        }
    }
    @RequestMapping("/delete")
    public int delete(@RequestParam int m_id) {
        int isDeleted = menuService.delete(m_id);
        log.info("删除成功：id={}", m_id);
        return isDeleted;
    }
    @PutMapping("/update")
    public int update(@RequestBody Menu menu) {
        int updatedScore = menuService.update(menu);
        log.info("更新成功:"+"id:"+menu.getM_id()+"名称："+menu.getName()+"价格："+menu.getPrice()+"数量："+menu.getQuantity());
        return updatedScore;
    }


    @RequestMapping("/select")
    public List<Menu> select(@RequestParam(defaultValue = "1") int pageNum,
                               @RequestParam(defaultValue = "10") int pageSize) {
        log.info("查询成功，页码={}，每页大小={}", pageNum, pageSize);
        return menuService.select(pageNum, pageSize);
    }
}