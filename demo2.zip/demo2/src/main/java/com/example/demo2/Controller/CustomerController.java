package com.example.demo2.Controller;

import com.example.demo2.Service.CustomerService;
import com.example.demo2.Service.MenuService;
import com.example.demo2.Service.UsersService;
import com.example.demo2.entity.Customer;
import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Users;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    @RequestMapping("/add")
    public ResponseEntity<String> add(@RequestBody Customer customer) {
        log.info("接收客户信息: {}", customer);
        try {
            customerService.add(customer);
            return ResponseEntity.ok("添加成功");
        } catch (Exception e) {
            log.error("添加失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("添加失败: " + e.getMessage());
        }
    }
    @RequestMapping("/delete")
    public int delete(@RequestParam int id) {
        int isDeleted = customerService.delete(id);
        log.info("删除成功：id={}", id);
        return isDeleted;
    }
    @PutMapping("/update")
    public int update(@RequestBody Customer customer) {
        int updatedScore = customerService.update(customer);
        log.info("更新成功:"+"id:"+customer.getId()+"姓名："+customer.getName()+"电话："+customer.getPhone()+"密码："+customer.getPassword());
        return updatedScore;
    }


    @RequestMapping("/select")
    public List<Menu> select(@RequestParam(defaultValue = "1") int pageNum,
                             @RequestParam(defaultValue = "10") int pageSize) {
        log.info("查询成功，页码={}，每页大小={}", pageNum, pageSize);
        return customerService.select(pageNum, pageSize);
    }
}