package com.example.demo2.Controller;

import com.example.demo2.Service.SuggestService;
import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Suggest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/suggest")
public class SuggestController {
    @Autowired
    private SuggestService suggestService;
    @RequestMapping("/add")
    public ResponseEntity<String> add(@RequestBody Suggest suggest) {
        log.info("接收到留言信息: {}", suggest);
        try {
            suggestService.add(suggest);
            return ResponseEntity.ok("添加成功");
        } catch (Exception e) {
            log.error("添加留言失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("添加失败: " + e.getMessage());
        }
    }
    @RequestMapping("/delete")
    public int delete(@RequestParam int id) {
        int isDeleted = suggestService.delete(id);
        log.info("删除成功：id={}", id);
        return isDeleted;
    }
    @PutMapping("/update")
    public int update(@RequestBody Suggest suggest) {
        int updatedScore = suggestService.update(suggest);
        log.info("更新成功:"+"id:"+suggest.getId()+"反馈："+suggest.getFeedback()+"留言："+suggest.getMessage()+"联系电话："+suggest.getPhone());
        return updatedScore;
    }


    @RequestMapping("/select")
    public List<Menu> select(@RequestParam(defaultValue = "1") int pageNum,
                             @RequestParam(defaultValue = "10") int pageSize) {
        log.info("查询成功，页码={}，每页大小={}", pageNum, pageSize);
        return suggestService.select(pageNum, pageSize);
    }
}