package com.example.demo2.Service;


import com.example.demo2.entity.Menu;
import com.example.demo2.mapper.MenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {
    @Autowired
    private MenuMapper menuMapper;

    public void add(Menu menu) {
        menuMapper.add(menu);
    }

    public int delete(int m_id) {
        return menuMapper.delete(m_id);
    }

    public int update(Menu menu) {
        return menuMapper.update(menu);
    }

    public List<Menu> select(int pageNum, int pageSize) {
        return menuMapper.select(pageNum,pageSize);
    }
}
