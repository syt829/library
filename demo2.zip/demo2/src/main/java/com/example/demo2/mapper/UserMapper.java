package com.example.demo2.mapper;

import com.example.demo2.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


@Mapper
public interface UserMapper {
    public User getUserById(@Param("id") int id);

    User findByUsername(String username);
}
