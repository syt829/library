package com.example.demo2.Controller;

import com.example.demo2.Service.OrdersService;
import com.example.demo2.entity.Orders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/order")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    @PostMapping("/submit")
    public ResponseEntity<Map<String, Object>> submitOrder(@RequestBody Orders order) {
        Map<String, Object> response = new HashMap<>();
        try {
            ordersService.saveOrder(order);
            response.put("success", true);
            response.put("message", "订单提交成功！");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "订单提交失败: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
}