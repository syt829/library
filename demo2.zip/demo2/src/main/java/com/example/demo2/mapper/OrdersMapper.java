package com.example.demo2.mapper;

import com.example.demo2.entity.Orders;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrdersMapper {
    void insertOrder(Orders orders);
}