package com.example.demo2.entity;

public class Suggest {
    private int id;
    private String feedback;
    private String message;
    private int phone;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Suggest{" +
                "id=" + id +
                ", feedback='" + feedback + '\'' +
                ", message='" + message + '\'' +
                ", phone=" + phone +
                '}';
    }
}
