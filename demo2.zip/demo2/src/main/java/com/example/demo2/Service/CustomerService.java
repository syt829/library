package com.example.demo2.Service;

import com.example.demo2.entity.Customer;
import com.example.demo2.entity.Menu;
import com.example.demo2.mapper.CustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CustomerService {
    @Autowired
    private CustomerMapper customerMapper;
    public void add(Customer customer) {
        customerMapper.add(customer);
    }

    public int delete(int id) {
        return customerMapper.delete(id);
    }

    public int update(Customer customer) {
        return customerMapper.update(customer);
    }

    public List<Menu> select(int pageNum, int pageSize) {
        return customerMapper.select(pageNum,pageSize);
    }
}
