package com.example.demo2.mapper;

import com.example.demo2.entity.Menu;
import com.example.demo2.entity.Suggest;

import java.util.List;

public interface SuggestMapper {
    void add(Suggest suggest);

    int delete(int id);

    int update(Suggest suggest);

    List<Menu> select(int pageNum, int pageSize);
}
