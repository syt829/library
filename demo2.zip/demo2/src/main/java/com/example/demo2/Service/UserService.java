package com.example.demo2.Service;


import com.example.demo2.entity.User;

public interface UserService {
    User login(String username, String password);
}
