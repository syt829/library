let currentPage = 1;
const itemsPerPage = 6; // 每页显示的商品数量
let cart = []; // 购物车数据

document.addEventListener('DOMContentLoaded', function () {
    fetchItems();
    setupEventListeners();
});

function fetchItems() {
    fetch('/orders/all')
        .then(response => response.json())
        .then(orders => {
            renderItems(orders);
            setupPagination(orders);
        })
        .catch(error => console.error('Error fetching items:', error));
}

function renderItems(orders) {
    const itemsContainer = document.getElementById('items-container');
    itemsContainer.innerHTML = '';
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    orders.slice(start, end).forEach(order => {
        const itemElement = document.createElement('div');
        itemElement.className = 'item';
        itemElement.innerHTML = `
            <img src="${order.imageUrl}" alt="${order.name}">
            <h2>${order.name}</h2>
            <p>${order.description}</p>
            <p class="price">￥${order.price.toFixed(2)}</p>
            <button onclick="addToCart(${order.orderid})">加入购物车</button>
        `;
        itemElement.addEventListener('click', () => showItemDetail(order));
        itemsContainer.appendChild(itemElement);
    });
}

function setupPagination(orders) {
    const totalPages = Math.ceil(orders.length / itemsPerPage);
    document.getElementById('page-info').textContent = `第 ${currentPage} 页`;
    document.getElementById('prev-page').disabled = currentPage === 1;
    document.getElementById('next-page').disabled = currentPage === totalPages;
}

document.getElementById('prev-page').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        fetchItems();
    }
});

document.getElementById('next-page').addEventListener('click', () => {
    currentPage++;
    fetchItems();
});

function addToCart(orderId) {
    fetch(`/orders/${orderId}`)
        .then(response => response.json())
        .then(order => {
            cart.push(order);
            alert(`已加入购物车: ${order.name}`);
        })
        .catch(error => console.error('Error adding to cart:', error));
}

function showItemDetail(order) {
    const modal = document.getElementById('item-detail-modal');
    document.getElementById('detail-name').textContent = order.name;
    document.getElementById('detail-image').src = order.imageUrl;
    document.getElementById('detail-description').textContent = order.description;
    document.getElementById('detail-price').textContent = order.price.toFixed(2);
    modal.style.display = 'block';
}

function setupEventListeners() {
    // 关闭弹窗
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        });
    });

    // 查看购物车
    document.getElementById('view-cart').addEventListener('click', () => {
        const modal = document.getElementById('cart-modal');
        const cartItems = document.getElementById('cart-items');
        cartItems.innerHTML = '';
        let total = 0;
        cart.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.name} - ￥${item.price.toFixed(2)}`;
            cartItems.appendChild(li);
            total += item.price;
        });
        document.getElementById('cart-total').textContent = total.toFixed(2);
        modal.style.display = 'block';
    });

    // 结算
    document.getElementById('checkout').addEventListener('click', () => {
        alert('结算成功！');
        cart = [];
        document.getElementById('cart-modal').style.display = 'none';
    });
}