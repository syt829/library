// 添加菜单
document.getElementById('add-menu-form')?.addEventListener('submit', function (event) {
    event.preventDefault();
    const menu = {
        m_id: parseInt(document.getElementById('m_id').value),
        name: document.getElementById('name').value,
        price: parseFloat(document.getElementById('price').value),
        quantity: parseInt(document.getElementById('quantity').value)
    };
    fetch('/scores/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(menu)
    })
        .then(response => response.text())
        .then(message => {
            alert(message);
            if (window.location.pathname.endsWith('menu-list.html')) {
                fetchMenus();
            }
        })
        .catch(error => console.error('Error adding menu:', error));
});

// 删除菜单
function deleteMenu(m_id) {
    if (confirm('确定要删除此菜单吗？')) {
        fetch(`/scores/delete?m_id=${m_id}`, {
            method: 'POST'
        })
            .then(response => response.text())
            .then(message => {
                alert(message);
                fetchMenus();
            })
            .catch(error => console.error('Error deleting menu:', error));
    }
}

// 更新菜单
function updateMenu(m_id) {
    const name = prompt('请输入新的菜单名称:');
    const price = parseFloat(prompt('请输入新的菜单价格:'));
    const quantity = parseInt(prompt('请输入新的菜单数量:'));
    if (name && !isNaN(price) && !isNaN(quantity)) {
        const menu = {
            m_id: m_id,
            name: name,
            price: price,
            quantity: quantity
        };
        fetch('/scores/update', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(menu)
        })
            .then(response => response.text())
            .then(message => {
                alert(message);
                fetchMenus();
            })
            .catch(error => console.error('Error updating menu:', error));
    } else {
        alert('输入无效，请重试。');
    }
}

// 查询菜单
document.getElementById('select-menu-form')?.addEventListener('submit', function (event) {
    event.preventDefault();
    fetchMenus();
});

// 获取菜单列表
function fetchMenus() {
    const pageNum = document.getElementById('pageNum').value;
    const pageSize = document.getElementById('pageSize').value;
    fetch(`/scores/select?pageNum=${pageNum}&pageSize=${pageSize}`)
        .then(response => response.json())
        .then(menus => {
            const menusTable = document.getElementById('menus-table').getElementsByTagName('tbody')[0];
            menusTable.innerHTML = '';
            menus.forEach(menu => {
                const row = menusTable.insertRow();
                row.insertCell().textContent = menu.m_id;
                row.insertCell().textContent = menu.name;
                row.insertCell().textContent = `￥${menu.price.toFixed(2)}`;
                row.insertCell().textContent = menu.quantity;
                const actionsCell = row.insertCell();
                actionsCell.className = 'actions';
                actionsCell.innerHTML = `
          <button onclick="updateMenu(${menu.m_id})">编辑</button>
          <button onclick="deleteMenu(${menu.m_id})">删除</button>
          <button onclick="addToGeneratedMenu(${menu.m_id})">添加</button>
        `;
            });
        })
        .catch(error => console.error('Error fetching menus:', error));
}

// 添加到生成菜单
let generatedMenuItems = [];
function addToGeneratedMenu(m_id) {
    fetch(`/scores/select?pageNum=1&pageSize=100`) // 获取所有菜单
        .then(response => response.json())
        .then(menus => {
            const menu = menus.find(m => m.m_id === m_id);
            if (menu) {
                generatedMenuItems.push(menu);
                alert(`已添加 ${menu.name} 到生成菜单`);
            }
        })
        .catch(error => console.error('Error fetching menu:', error));
}

// 生成菜单
function generateMenu() {
    const menuItemsList = document.getElementById('menu-items');
    menuItemsList.innerHTML = '';
    generatedMenuItems.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - ￥${item.price.toFixed(2)} (数量: ${item.quantity})`;
        menuItemsList.appendChild(li);
    });
}

// 页面加载时查询菜单
if (window.location.pathname.endsWith('menu-list.html')) {
    fetchMenus();
}